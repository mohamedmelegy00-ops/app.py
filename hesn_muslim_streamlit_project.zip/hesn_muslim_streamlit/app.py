# -*- coding: utf-8 -*-
import json
import os
from pathlib import Path

import requests
import streamlit as st

st.set_page_config(
    page_title="حصن المسلم والقرآن الكريم",
    page_icon="📖",
    layout="centered",
    initial_sidebar_state="collapsed",
)

API = "https://api.alquran.cloud/v1"

RECITERS = [
    ("مشاري العفاسي", "ar.alafasy"),
    ("عبدالباسط عبدالصمد", "ar.abdulbasit"),
    ("عبدالرحمن السديس", "ar.abdurrahmaansudais"),
    ("محمود خليل الحصري", "ar.husary"),
    ("محمد صديق المنشاوي", "ar.minshawi"),
    ("ماهر المعيقلي", "ar.mahermuaiqly"),
    ("سعود الشريم", "ar.saoodshuraym"),
    ("أبو بكر الشاطري", "ar.shaatree"),
    ("محمد أيوب", "ar.muhammadayyoub"),
    ("محمد جبريل", "ar.muhammadjibreel"),
]

DEFAULT_ADHKAR = [
    {"category": "أذكار الصباح والمساء", "text": "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ.", "count": 1},
    {"category": "أذكار الصباح والمساء", "text": "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.", "count": 100},
    {"category": "أذكار الصباح والمساء", "text": "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ.", "count": 100},
    {"category": "أذكار النوم", "text": "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا.", "count": 1},
    {"category": "أذكار الاستيقاظ", "text": "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ.", "count": 1},
    {"category": "أذكار الصلاة", "text": "أَسْتَغْفِرُ اللَّهَ.", "count": 3},
    {"category": "أذكار متنوعة", "text": "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ.", "count": 1},
    {"category": "أذكار متنوعة", "text": "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ.", "count": 10},
]

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=Cairo:wght@400;600;700&display=swap');
html, body, [class*="css"] { font-family: 'Cairo', sans-serif; }
.block-container { max-width: 900px; padding-top: 1rem; padding-bottom: 4rem; }
.app-header { text-align:center; padding: 1rem 0 .4rem; }
.app-header h1 { font-family:'Amiri',serif; font-size:2.3rem; margin-bottom:.2rem; }
.app-subtitle { opacity:.75; font-size:.95rem; }
.ayah { font-family:'Amiri',serif; font-size:1.55rem; line-height:2.25; text-align:right; direction:rtl; padding:.55rem .25rem; }
.dhikr { font-family:'Amiri',serif; font-size:1.75rem; line-height:2.1; text-align:center; direction:rtl; padding:1rem .6rem; }
.watermark { text-align:center; opacity:.55; font-size:.8rem; padding-top:1.5rem; }
div.stButton > button { border-radius: 12px; min-height: 2.8rem; }
@media (max-width: 600px) {
 .app-header h1 { font-size:1.8rem; }
 .ayah { font-size:1.35rem; line-height:2.1; }
 .dhikr { font-size:1.5rem; }
 .block-container { padding-left: .8rem; padding-right: .8rem; }
}
</style>
""", unsafe_allow_html=True)

def load_adhkar():
    path = Path(__file__).with_name("adhkar.json")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return DEFAULT_ADHKAR

@st.cache_data(ttl=3600, show_spinner=False)
def get_surahs():
    response = requests.get(f"{API}/surah", timeout=20)
    response.raise_for_status()
    return response.json()["data"]

@st.cache_data(ttl=3600, show_spinner=False)
def get_surah(number):
    response = requests.get(f"{API}/surah/{number}", timeout=25)
    response.raise_for_status()
    return response.json()["data"]

@st.cache_data(ttl=3600, show_spinner=False)
def get_available_editions():
    response = requests.get(f"{API}/edition/format/audio", timeout=20)
    response.raise_for_status()
    return {item.get("identifier") for item in response.json()["data"]}

def audio_url(surah_number, edition):
    # AlQuran Cloud's audio-surah endpoint convention.
    return f"https://cdn.islamic.network/quran/audio-surah/128/{edition}/{surah_number}.mp3"

if "dark_mode" not in st.session_state:
    st.session_state.dark_mode = True
if "dhikr_counts" not in st.session_state:
    st.session_state.dhikr_counts = {}
if "selected_surah" not in st.session_state:
    st.session_state.selected_surah = 1

dark = st.session_state.dark_mode
if dark:
    st.markdown("""
    <style>
    .stApp { background:#101916; color:#f1f4ed; }
    [data-testid="stSidebar"] { background:#17231e; }
    div[data-baseweb="select"] > div { background:#1b2923; }
    </style>
    """, unsafe_allow_html=True)
else:
    st.markdown("""
    <style>
    .stApp { background:#fbfaf5; color:#1b2b23; }
    </style>
    """, unsafe_allow_html=True)

st.markdown("""
<div class="app-header">
  <h1>📖 حصن المسلم والقرآن الكريم</h1>
  <div class="app-subtitle">القرآن الكريم • الأذكار • التلاوة</div>
</div>
""", unsafe_allow_html=True)

top1, top2 = st.columns([3, 2])
with top1:
    watermark = st.text_input("العلامة المائية", value="حصن المسلم • تطبيق مجاني", label_visibility="collapsed", placeholder="اكتب العلامة المائية")
with top2:
    if st.button("🌙 / ☀️ تبديل الوضع", use_container_width=True):
        st.session_state.dark_mode = not st.session_state.dark_mode
        st.rerun()

tab_quran, tab_adhkar, tab_about = st.tabs(["📖 القرآن الكريم", "🤲 الأذكار", "ℹ️ حول التطبيق"])

with tab_quran:
    try:
        surahs = get_surahs()
        surah_labels = [f"{s['number']}. {s['name']} — {s['englishName']}" for s in surahs]
        selected_label = st.selectbox("اختر السورة", surah_labels, index=min(st.session_state.selected_surah - 1, len(surahs)-1))
        selected_number = int(selected_label.split(".")[0])
        st.session_state.selected_surah = selected_number
        surah = surahs[selected_number - 1]

        available = get_available_editions()
        available_reciters = [(name, ident) for name, ident in RECITERS if ident in available]
        if not available_reciters:
            available_reciters = [("مشاري العفاسي", "ar.alafasy")]
        reciter_names = [name for name, _ in available_reciters]
        chosen_reciter = st.selectbox("اختر القارئ", reciter_names)
        edition = dict(available_reciters)[chosen_reciter]

        audio = audio_url(selected_number, edition)
        st.audio(audio, format="audio/mp3")
        st.caption(f"السورة: {surah['name']} • عدد الآيات: {surah['numberOfAyahs']} • القارئ: {chosen_reciter}")

        with st.spinner("جارٍ تحميل الآيات..."):
            full_surah = get_surah(selected_number)
        st.markdown(f"### سورة {full_surah['name']}")
        for ayah in full_surah["ayahs"]:
            st.markdown(
                f"<div class='ayah'>{ayah['text']} <span style='font-size:.85em;opacity:.7'>۞ {ayah['numberInSurah']}</span></div>",
                unsafe_allow_html=True
            )
            st.divider()
    except Exception:
        st.error("تعذر الاتصال بخدمة القرآن. تحقق من الإنترنت ثم أعد المحاولة.")

with tab_adhkar:
    adhkar = load_adhkar()
    categories = sorted(set(item.get("category", "أذكار متنوعة") for item in adhkar))
    category = st.selectbox("قسم الأذكار", categories)
    items = [item for item in adhkar if item.get("category") == category]
    if "dhikr_index" not in st.session_state:
        st.session_state.dhikr_index = 0
    if st.session_state.get("last_category") != category:
        st.session_state.dhikr_index = 0
        st.session_state.last_category = category
    if items:
        idx = min(st.session_state.dhikr_index, len(items)-1)
        item = items[idx]
        key = f"{category}:{idx}"
        current = st.session_state.dhikr_counts.get(key, 0)
        st.markdown(f"<div class='dhikr'>{item['text']}</div>", unsafe_allow_html=True)
        st.markdown(f"<div style='text-align:center'>الذكر {idx+1} من {len(items)}</div>", unsafe_allow_html=True)
        st.progress(min(current / max(int(item.get("count", 1)), 1), 1.0))
        st.markdown(f"<div style='text-align:center'>التكرار: <b>{current}</b> / {item.get('count', 1)}</div>", unsafe_allow_html=True)
        c1, c2, c3 = st.columns(3)
        with c1:
            if st.button("➕ تكرار", use_container_width=True):
                st.session_state.dhikr_counts[key] = min(current + 1, int(item.get("count", 1)))
                st.rerun()
        with c2:
            if st.button("إعادة العداد", use_container_width=True):
                st.session_state.dhikr_counts[key] = 0
                st.rerun()
        with c3:
            if st.button("الذكر التالي ➜", use_container_width=True):
                st.session_state.dhikr_index = (idx + 1) % len(items)
                st.rerun()
        st.caption("هذه مجموعة أذكار بداية وليست جميع كتاب حصن المسلم. راجع النصوص والتكرارات من مصدر موثوق قبل النشر.")

with tab_about:
    st.markdown("""
    ### عن التطبيق
    تطبيق تجريبي يجمع القرآن الكريم والأذكار في واجهة واحدة.

    - واجهة متجاوبة للهاتف والكمبيوتر.
    - الوضع الليلي والنهاري.
    - اختيار القارئ من الإصدارات الصوتية التي توفرها الخدمة.
    - علامة مائية قابلة للتعديل من أعلى الصفحة.

    **تنبيه:** يلزم الاتصال بالإنترنت لعرض القرآن وتشغيل الصوت. قد تتغير خدمات الصوت الخارجية. راجع نصوص الأذكار من طبعة موثوقة قبل توزيع التطبيق.
    """)

st.markdown(f"<div class='watermark'>{watermark}</div>", unsafe_allow_html=True)
